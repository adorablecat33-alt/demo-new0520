# TRS — 操盤室風控交易系統

> **Trading Risk Management System** · Phase 1 Demo

多帳號風控與下單管理系統 — 前端 Demo 展示版本，部署於 Vercel。

---

## 系統定位

本系統核心理念：**「先風控，再交易」**

- ✅ 可控 · 可追蹤 · 可稽核 · 可對帳
- ✅ 多交易員、多券商、多帳號管理
- ✅ 保留人工決策權限
- ✅ 逐步開放自動化能力

---

## 頁面結構

| 頁面 | 路徑 | 說明 |
|------|------|------|
| 登入入口 | `/index.html` | 角色選擇登入 |
| 交易員下單 | `/pages/trader.html` | 下單介面、持倉、K線、委託、稽核 |
| 系統後台 | `/pages/admin.html` | 交易員矩陣、帳號管理、風控規則 |
| 風險警報 | `/pages/risk-alert.html` | 即時警報串流、熔斷操作 |

---

## 功能展示

### 交易員下單頁 (`trader.html`)
- 三欄式交易介面（持倉 / K線 / 下單）
- Pre-Trade 風控即時檢查清單
- 二次確認 Modal（大額 / 市價 / 警戒）
- ⚡ 閃電模式（高速人工下單）
- 五檔報價即時跳動
- 委託記錄、成交回報、稽核日誌 Tab
- 交易員 / 帳號快速切換

### 系統後台 (`admin.html`)
- 4 項 KPI 即時數據
- 交易員矩陣（日損/額度進度條、鎖定/熔斷按鈕）
- 券商帳號管理（新增/鎖定）
- 風控規則編輯（含修改原因強制填寫）
- Append-Only 稽核日誌

### 風險警報 (`risk-alert.html`)
- 即時警報串流（危險/警戒/一般）
- 自動模擬新警報推送
- 交易員風險熱力圖
- 快速操作：鎖定、凍結、全局熔斷
- 熔斷橫幅提示

---

## 交易員角色

| 角色 | 類型 | 說明 |
|------|------|------|
| 交易員A | 丙種 (`CAPITAL`) | 使用外部資金，日損警戒 44.5% |
| 交易員B | 丙種 (`CAPITAL`) | 風險指標超標 121% |
| 交易員C | 自有 (`PROP`) | 使用自有資金，狀態正常 |

---

## 風控引擎流程

```
委託送出
  ↓ 交易員啟用確認
  ↓ 帳號狀態確認
  ↓ 商品許可確認
  ↓ 單筆口數限制 (max 200口)
  ↓ 單筆金額限制
  ↓ 今日虧損檢查 (40% 警戒 / 80% 熔斷)
  ↓ 帳號鎖定確認
  ↓ 大額/市價 → 二次確認 Modal
  ↓ 送出 + 稽核記錄
```

---

## 部署方式（Vercel）

```bash
# 1. clone 或下載此專案
git clone https://github.com/your-repo/trs-demo

# 2. 推上 GitHub

# 3. 到 vercel.com → New Project → Import GitHub Repo

# 4. 直接 Deploy（純靜態，不需 Build Command）
```

---

## 技術架構（Demo 版）

- **純前端靜態** HTML + CSS + Vanilla JS
- **零依賴** 無需 npm install
- **共用 CSS** `/css/main.css`
- **共用 JS** `/js/common.js`（AppState、工具函數）
- **Vercel Static** 直接部署

---

## 後續規劃

| Phase | 內容 |
|-------|------|
| Phase 1 ✅ | 前端 Demo 展示 |
| Phase 2 | NestJS Backend + PostgreSQL |
| Phase 3 | 真實券商 Adapter 接入 |
| Phase 4 | 條件式自動路由 |
| Phase 5 | AI 風控助理 |

---

## 核心設計原則

1. **請求帳號 ≠ 實際送出帳號**（`requested_account_id` vs `routed_account_id`）
2. **Append-Only 稽核日誌**（不可刪除、不可修改）
3. **先安全，再自動化**
4. **人工決策保留**（高風險一律二次確認）

---

*© 2026 TRS Demo · Phase 1 · 模擬下單展示*
